
PHONEGAP
http://drupal.org/project/phonegap
====================================

DESCRIPTION
-----------
This project with its pairing phongap app is a bridge between Native apps on mobile and Drupal

FEATURES
-----------
- Mobile Authentication (from within Native app)
- Mobile uploading of content (from within Native app)
- Mobile display of Drupal VIews (from within Native app)

INSTALLATION
-----------
1) Copy phonegap directory to your modules directory
2) Enable the module at module administration page
3) Enable permission to upload content to mobile on the permissions page
4) Install and enable Views if you wish to display
5) Install Drugap on your Android
6) From the app go to settings and enter the URL of your site
7) On the same settings page enter the name and display for the View you wish to use to return content
8) Save settings
9) On the mobile app, go to account and log in
10)Upload content from you mobile and view it back on the device 
