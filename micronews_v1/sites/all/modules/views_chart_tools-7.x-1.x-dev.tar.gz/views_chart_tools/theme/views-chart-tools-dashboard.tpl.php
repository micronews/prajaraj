<div class="views-chart-tools-dashboard" id="<?php echo $dashboard_id; ?>">
  <?php foreach ($elements as $content):?>
    <?php echo $content; ?>
  <?php endforeach; ?>
</div>